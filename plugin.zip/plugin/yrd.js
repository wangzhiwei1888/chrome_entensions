$(function(){

	$("#btn1").on("click",function(){

		$("body").append('test-----------');
		
	})
})